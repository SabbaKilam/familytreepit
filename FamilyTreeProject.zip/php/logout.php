<?php
	session_start();
	session_destroy();
	$_SESSION = array();
	exit("deny");
?>